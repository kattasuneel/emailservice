export interface MailList {
    mailid:string,
    color?:'red'|'green'
  }